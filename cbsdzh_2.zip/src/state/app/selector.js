export function selectApp(state) {
  return state.app;
}
