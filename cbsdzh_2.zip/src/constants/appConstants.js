export const MAIN_PAGE = 'mainPage';
export const WAITING_FOR_PLAYERS = 'waitingForPlayers';
export const IN_GAME = 'inGame';
