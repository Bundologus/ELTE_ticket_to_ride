/* export const PLAYER_FIRST_ROUND = 'playerFirstRound';
export const PLAYER_BEGIN = 'playerBegin';
export const PLAYER_DRAW_TRAIN = 'playerDrawTrain';
export const PLAYER_DRAW_ROUTES = 'playerDrawRoutes';
export const PLAYER_BUILD = 'playerBuild';
export const PLAYER_DONE = 'playerDone'; */

export const PLAYER_COLORS = ['green', 'blue', 'yellow', 'red', 'black'];
