import './App.css';
import { Layout } from './views/layout/Layout';

function App() {
  return <Layout></Layout>;
}

export default App;
